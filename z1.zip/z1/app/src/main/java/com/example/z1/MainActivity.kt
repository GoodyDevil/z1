package com.example.z1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.TextureView
import android.view.View
import android.widget.Button
import android.widget.TextView
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun z1(view: View) {
        val textView2 = findViewById<TextView>(R.id.textView)
        val random = Random.nextInt(10, 99) + 1
        textView2.text = random.toString()

    }
}